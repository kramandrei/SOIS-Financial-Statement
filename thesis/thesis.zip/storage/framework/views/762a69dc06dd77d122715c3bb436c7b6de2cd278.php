
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Patient Quotation Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('patients.index')); ?>">Patients Module</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Patient Quotation</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#addNew"><i class="fa fa-plus-circle"></i> Create Entry</button>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($checkQuote == NULL): ?>
    <div class="row">
        <div class="col-12">
            <div class="alert alert-success border-0 bg-success alert-dismissible fade show" style="text-transform: uppercase; color: white;">
                <?php if($checkCase != NULL): ?>
                <h5>Latest Case Setup</h5>
                <ul>
                    <li>Case Setup Name: <?php echo e($checkCase->implantcase->name); ?></li>
                    <li>Surgeon Name: <?php echo e($checkCase->surgeon->name); ?></li>
                    <li>Hospital Name: <?php echo e($checkCase->hospital->name); ?></li>
                    <li>Agent Name: <?php echo e($checkCase->agent->code); ?></li>
                </ul>
                <?php else: ?>
                <h5>NO CASE SETUP YET</h5>
                <?php endif; ?> 
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="row">
        <div class="col-12">
            <div class="alert alert-success border-0 bg-success alert-dismissible fade show" style="text-transform: uppercase; color: white;">
                <?php if($checkCase != NULL): ?>
                <h5>Latest Case Setup</h5>
                <ul>
                    <li>Case Setup Name: <?php echo e($checkCase->implantcase->name); ?></li>
                    <li>Surgeon Name: <?php echo e($checkCase->surgeon->name); ?></li>
                    <li>Hospital Name: <?php echo e($checkCase->hospital->name); ?></li>
                    <li>Agent Name: <?php echo e($checkCase->agent->code); ?></li>
                </ul>
                <?php else: ?>
                <h5>NO CASE SETUP YET</h5>
                <?php endif; ?> 
            </div>
        </div>
    </div>
    <?php endif; ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <table class="table table-striped table1" style="text-transform: uppercase;">
                    <thead>
                        <tr>
                            <th class="text-center">Date</th>
                            <th class="text-center">Agent</th>
                            <th class="text-center">To</th>
                            <th class="text-center">Hospital</th>
                            <th class="text-center">Surgeon</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">GL Amount</th>
                            <th class="text-center">Cash Amount</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d[1]); ?></td>
                            <td><?php echo e($d[2]); ?></td>
                            <td><?php echo e($d[3]); ?></td>
                            <td><?php echo e($d[4]); ?></td>
                            <td><?php echo e($d[5]); ?></td>
                            <td><?php echo e($d[6]); ?></td>
                            <td><?php echo e($d[7]); ?></td>
                            <td><?php echo e($d[8]); ?></td>
                            <td class="text-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary btn-sm"><i class="fa fa-wrench"></i></button>
                                    <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"><span class="visually-hidden">Toggle Dropdown</span>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#edit<?php echo e($d[0]); ?>" data-bs-toggle="modal">Edit Entry</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#refund<?php echo e($d[0]); ?>" data-bs-toggle="modal">Request for Refund</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#edit'.$d[0].'" data-bs-toggle="modal">Print Entry</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(action('PatientController@quote_payment_list',$d[0])); ?>">Create Payment</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#add<?php echo e($d[0]); ?>" data-bs-toggle="modal">Add Item</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(action('PatientController@view_quote_item',$d[0])); ?>">View Quotation List</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#GL<?php echo e($d[0]); ?>" data-bs-toggle="modal">Create GL</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#RC<?php echo e($d[0]); ?>" data-bs-toggle="modal">Attach Slip</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#RX<?php echo e($d[0]); ?>" data-bs-toggle="modal">Attach RX</a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('modals'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit<?php echo e($d[0]); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'PATCH','action'=>['PatientController@update_patient_quotation_list',$d[0]]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Update Patient Quotation:</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="date" class="col-sm-3 col-form-label">Date</label>
                                <div class="col-sm-9">
                                    <input type="text" name="date" class="form-control" id="date" value="<?php echo e($d[9]); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="agent_id" class="col-sm-3 col-form-label">Select Agent</label>
                                <div class="col-sm-9">
                                    <select name="agent_id" id="agent_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($a->id); ?>" <?php echo e(($d[2] == $a->code) ? 'selected' : ''); ?>><?php echo e($a->code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="to_address" class="col-sm-3 col-form-label">To</label>
                                <div class="col-sm-9">
                                    <input type="text" name="to_address" class="form-control" id="to_address" value="<?php echo e($d[3]); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="hospital_id" class="col-sm-3 col-form-label">Select Hospital</label>
                                <div class="col-sm-9">
                                    <select name="hospital_id" id="hospital_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($h->id); ?>" <?php echo e(($d[4] == $h->name) ? 'selected' : ''); ?>><?php echo e($h->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="surgeon_id" class="col-sm-3 col-form-label">Select Surgeon</label>
                                <div class="col-sm-9">
                                    <select name="surgeon_id" id="surgeon_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $surgeons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->id); ?>" <?php echo e(($d[5] == $s->name) ? 'selected' : ''); ?>><?php echo e($s->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- REFUND -->
<div class="modal fade" id="refund<?php echo e($d[0]); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@request_refund',$d[0]]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Request for Refund</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="amount" class="col-sm-3 col-form-label">Refund Amount</label>
                                <div class="col-sm-9">
                                    <input type="text" name="amount" class="form-control" id="amount" value="0.00">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- ATTACH SLIP -->
<div class="modal fade" id="RC<?php echo e($d[0]); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@post_rc_slip',$d[0]],'novalidate' => 'novalidate','files' => 'true']); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Attach Slip</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="deposit_slip" class="col-sm-3 col-form-label">Attach Deposit Slip</label>
                                <div class="col-sm-9">
                                    <?php if($checkRC != NULL): ?>
                                    <img class="media-object mb-2" src="<?php echo asset('/gl/'.$checkRC->deposit_slip); ?>" height="150" width="150">
                                    <?php endif; ?>
                                    <input type="file" name="deposit_slip" class="form-control" id="deposit_slip">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_slip" class="col-sm-3 col-form-label">Attach Receipt Slip</label>
                                <div class="col-sm-9">
                                    <?php if($checkRC != NULL): ?>
                                    <img class="media-object mb-2" src="<?php echo asset('/gl/'.$checkRC->receipt_slip); ?>" height="150" width="150">
                                    <?php endif; ?>
                                    <input type="file" name="receipt_slip" class="form-control" id="receipt_slip">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- ATTACH RX -->
<div class="modal fade" id="RX<?php echo e($d[0]); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@post_rx_slip',$d[0]],'novalidate' => 'novalidate','files' => 'true']); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Attach Slip</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="rx_slip" class="col-sm-3 col-form-label">Attach RX Slip</label>
                                <div class="col-sm-9">
                                    <?php if($checkRX != NULL): ?>
                                    <img class="media-object mb-2" src="<?php echo asset('gl/'.$checkRX->rx_slip); ?>" height="150" width="150">
                                    <?php endif; ?>
                                    <input type="file" name="rx_slip" class="form-control" id="rx_slip">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- ATTACH GL -->
<div class="modal fade" id="GL<?php echo e($d[0]); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@post_gl',$d[0]],'novalidate' => 'novalidate','files' => 'true']); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Create GL</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="up_img" class="col-sm-3 col-form-label">Attach GL Slip</label>
                                <div class="col-sm-9">
                                    <?php if($checkGL != NULL): ?>
                                    <img class="media-object mb-2" src="<?php echo asset('gl/'.$checkGL->up_img); ?>" height="150" width="150">
                                    <?php endif; ?>
                                    <input type="file" name="up_img" class="form-control" id="up_img">
                                    <input type="hidden" name="patient_id" class="form-control" id="patient_id" value="<?php echo e($patient->id); ?>">
                                    <input type="hidden" name="quotation_id" class="form-control" id="quotation_id" value="<?php echo e($d[0]); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="date" class="col-sm-3 col-form-label">Date</label>
                                <div class="col-sm-9">
                                    <?php if($checkGL != NULL): ?>
                                    <input type="text" name="date" class="form-control" id="date" value="<?php echo e($checkGL->date); ?>">
                                    <?php else: ?>
                                    <input type="date" name="date" class="form-control" id="date">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="charity" class="col-sm-3 col-form-label">Charity</label>
                                <div class="col-sm-9">
                                    <?php if($checkGL != NULL): ?>
                                    <input type="text" name="charity" class="form-control" id="charity" value="<?php echo e($checkGL->charity); ?>">
                                    <?php else: ?>
                                    <input type="text" name="charity" class="form-control" id="charity">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="reference_code" class="col-sm-3 col-form-label">Reference Code</label>
                                <div class="col-sm-9">
                                    <?php if($checkGL != NULL): ?>
                                    <input type="text" name="reference_code" class="form-control" id="reference_code" value="<?php echo e($checkGL->reference_code); ?>">
                                    <?php else: ?>
                                    <input type="text" name="reference_code" class="form-control" id="reference_code">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="amount" class="col-sm-3 col-form-label">Amount</label>
                                <div class="col-sm-9">
                                    <?php if($checkGL != NULL): ?>
                                    <input type="text" name="amount" class="form-control" id="amount" value="<?php echo e($checkGL->amount); ?>">
                                    <?php else: ?>
                                    <input type="text" name="amount" class="form-control" id="amount" value="0.00">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <?php if($checkGL != NULL): ?>
                <a href="<?php echo e(action('PatientController@delete_gl',$d[0])); ?>" class="btn btn-danger">Delete GL</a>
                <?php endif; ?>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- ADD QUOTE ITEM -->
<div class="modal fade" id="add<?php echo e($d[0]); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@add_quote_item',$d[0]]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Add Quotation Item</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="uom" class="col-sm-3 col-form-label">UOM</label>
                                <div class="col-sm-9">
                                    <input type="text" name="uom" class="form-control" id="uom">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="description" class="col-sm-3 col-form-label">Description</label>
                                <div class="col-sm-9">
                                    <textarea name="description" class="form-control" id="description"></textarea>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="amount" class="col-sm-3 col-form-label">Amount</label>
                                <div class="col-sm-9">
                                    <input type="text" name="amount" class="form-control" id="amount" value="0.00">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="addNew" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@store_patient_quotation_list',$patient->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Create Patient Quotation</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="date" class="col-sm-3 col-form-label">Date</label>
                                <div class="col-sm-9">
                                    <input type="date" name="date" class="form-control" id="date">
                                    <input type="hidden" name="patient_id" class="form-control" id="patient_id" value="<?php echo e($patient->id); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="agent_id" class="col-sm-3 col-form-label">Select Agent</label>
                                <div class="col-sm-9">
                                    <select name="agent_id" id="agent_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="to_address" class="col-sm-3 col-form-label">To</label>
                                <div class="col-sm-9">
                                    <input type="text" name="to_address" class="form-control" id="to_address">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="hospital_id" class="col-sm-3 col-form-label">Select Hospital</label>
                                <div class="col-sm-9">
                                    <select name="hospital_id" id="hospital_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($h->id); ?>"><?php echo e($h->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="surgeon_id" class="col-sm-3 col-form-label">Select Surgeon</label>
                                <div class="col-sm-9">
                                    <select name="surgeon_id" id="surgeon_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $surgeons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="uom" class="col-sm-3 col-form-label">UOM</label>
                                <div class="col-sm-9">
                                    <input type="text" name="uom" class="form-control" id="uom">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="description" class="col-sm-3 col-form-label">Description</label>
                                <div class="col-sm-9">
                                    <textarea name="description" class="form-control" id="description"></textarea>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="amount" class="col-sm-3 col-form-label">Amount</label>
                                <div class="col-sm-9">
                                    <input type="text" name="amount" class="form-control" id="amount" value="0.00">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\agents\resources\views/admin/patients/quotations.blade.php ENDPATH**/ ?>