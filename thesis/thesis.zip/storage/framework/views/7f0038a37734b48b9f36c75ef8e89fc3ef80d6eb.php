
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Case Setup Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('cases.index')); ?>">Case Setups</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create Payment</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a href="<?php echo e(action('CaseController@print_voucher_form',$case->id)); ?>" class="btn btn-primary"><i class="fa fa-print"></i> Print Voucher</a>
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <div class="row mb-3">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td colspan="5" class="text-center" height="10px;" style="text-transform: uppercase;">Remittances,Excess and Rebates</td>
                            </tr>
                            <tr>
                                <td colspan="5" class="text-center" height="10px;" style="text-transform: uppercase;">&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="text-right">VAT Amount</td>
                                <td class="text-right">
                                    <?php echo e(number_format($mv,2)); ?>

                                </td>
                                <td></td>
                                <td class="text-right">Total Amount Due</td>
                                <td class="text-right"><?php echo e(number_format($alltotal,2)); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right">Withholding Tax</td>
                                <td class="text-right"><?php echo e(number_format($voucher->allvats()->sum('wh_amount'),2)); ?></td>
                                <td></td>
                                <td class="text-right">Remittances</td>
                                <td class="text-right">
                                    <?php if($voucher->si_payments->sum('si_amount') == 0): ?>
                                    <?php echo e(number_format(0,2)); ?>

                                    <?php else: ?>
                                    <?php echo e(number_format(($less + $other_expenses_cases->sum('amount') + $mv - $voucher->less) * -1,2)); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right">Implant Cost</td>
                                <td class="text-right"><?php echo e(number_format($implantcost - $voucher->less,2)); ?></td>
                                <td></td>
                                <td class="text-right">Surgeon Rebates </td>
                                <td class="text-right"><?php echo e(number_format($voucher->rebates * -1,2)); ?></td>
                            </tr>
                            <tr>
                                <td  class="text-right">Other Expenses Summary</td>
                                <td>
                                    <ul>
                                        <?php $__currentLoopData = $other_expenses_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($oec->expense->name); ?> - <?php echo e(number_format($oec->amount,2)); ?>

                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </td>
                                <td></td>
                                <td class="text-right">Agent Commission </td>
                                <td class="text-right"><?php echo e(number_format($agent_commission*-1,2)); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right">Total Other Expenses </td>
                                <td class="text-right"><?php echo e(number_format($other_expenses_cases->sum('amount'),2)); ?></td>
                                <td></td>
                                <td class="text-right">Office Excess </td>
                                <td class="text-right"><?php echo e(number_format($office_excess*-1,2)); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right">Transportation Delivery </td>
                                <td class="text-right"><?php echo e(number_format($deltrans,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td class="text-right">Transportation Pullout</td>
                                <td class="text-right"><?php echo e(number_format($pulltrans,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td class="text-right">Autoclave Inside Fee </td>
                                <td class="text-right"><?php echo e(number_format($clave_amt2,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php $__currentLoopData = $cer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-right"><?php echo e($cr->cer->name); ?> </td>
                                <td class="text-right"><?php echo e(number_format($cr->amount,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($voucher->cpr_amt > 0): ?>
                            <tr>
                                <td class="text-right">Old CPR</td>
                                <td class="text-right"><?php echo e(number_format($voucher->cpr_amt,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($old_trans_amt > 0): ?>
                            <tr>
                                <td class="text-right">Old Transportation</td>
                                <td class="text-right"><?php echo e(number_format($old_trans_amt,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($food_amt > 0): ?>
                            <tr>
                                <td class="text-right">Old Food</td>
                                <td class="text-right"><?php echo e(number_format($food_amt,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($clave_amt1 > 0): ?>
                            <tr>
                                <td class="text-right">Old Autoclave</td>
                                <td class="text-right"><?php echo e(number_format($clave_amt1,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($shipment_amt > 0): ?>
                            <tr>
                                <td class="text-right">Old Shipment</td>
                                <td class="text-right"><?php echo e(number_format($shipment_amt,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($park_amt > 0): ?>
                            <tr>
                                <td class="text-right">Old Parking</td>
                                <td class="text-right"><?php echo e(number_format($park_amt,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($toll_amt > 0): ?>
                            <tr>
                                <td class="text-right">Old Tollgate</td>
                                <td class="text-right"><?php echo e(number_format($toll_amt,2)); ?></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td class="text-right">Remittances</td>
                                <td class="text-right"><?php echo e(number_format($less  + $other_expenses_cases->sum('amount') + $mv - $voucher->less ,2)); ?></td>
                                <td></td>
                                <td class="text-right">Net </td>
                                <td class="text-right">
                                    <?php $zero_rate = 0; ?>
                                    <?php if($voucher->si_payments->sum('si_amount') == 0): ?>
                                    <?php echo e(number_format(0,2)); ?>

                                    <?php else: ?>
                                        <?php 
                                            $zerorate = \App\Case_zero_rate::where('case_setup_id',$case->id)
                                                ->first();
                                            if($zerorate == NULL){
                                                $zero_rate = 0;
                                            }else{
                                                $zero_rate = $zerorate->net;
                                            }
                                            $balancepaid = \App\Case_balance::where('case_setup_id',$case->id)
                                                ->where('isPaid',1)
                                                ->sum('amount');
                                        ?>
                                        <?php echo e(number_format((($alltotal - ($less + $other_expenses_cases->sum('amount') - $voucher->less + $mv + $voucher->rebates + $agent_commission + $office_excess) + $balances->where('isPaid',0)->sum('amount')) - $zero_rate) - $balancepaid,2)); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="card mt-2">
        <div class="card-body">
            <h5 class="card-title">Create Payment</h5>
            <div class="border p-4 rounded">
                <div class="row mb-3">
                    <table class="table table-striped" style="font-size: 11px;text-transform:uppercase;">
                        <thead>
                            <tr>
                                <th class="text-center">Payment Type</th>
                                <th class="text-center">Total Amount Due</th>
                                <th class="text-center">Receipt #</th>
                                <th class="text-center">Amount Collected</th>
                                <th class="text-center">Amount Deposited</th>
                                <th class="text-center">Amount Paid</th>
                                <th class="text-center">WH</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $case->si_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $csi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $crn = \App\Case_collection::where('case_setup_id',$case->id)
                                    ->where('si_payment_id',$csi->id)
                                    ->first();
                                $si_payment_detail = \App\Case_si_payment::where('id',$csi->id)->first();
                                $receipt_type = \App\Payment_type_detail::where('id',$si_payment_detail->payment_type_detail_id)->first();
                                if($crn != NULL){
                                    if($receipt_type->receipt_type == 3){
                                        $rc = 'CRN';
                                    }else{
                                        $rc = $receipt_type->receipt->name;
                                    }
                                    $crn_number = $rc.' - '.$crn->crn;
                                }else{
                                    $crn_number = 'OPEN';
                                }
                            ?>
                            <tr>
                                <td class="text-end">
                                    <?php echo e($csi->payment_detail->paymenttype->name); ?> - [<?php echo e($csi->payment_detail->detail->name); ?> - <?php echo e($csi->payment_detail->receipt->name); ?>] |
                                    <?php echo e($csi->payment_detail->receipt->name); ?> - <?php echo e($csi->receipt_number); ?>

                                </td>
                                <td class="text-center">
                                    <?php if($crn!= NULL && $crn->total_amount_due > 0): ?>
                                    <?php echo e(number_format($crn->total_amount_due,2)); ?>

                                    <?php else: ?>
                                    <?php echo e(number_format($csi->si_amount,2)); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="text-center">  
                                    <?php echo e($crn_number); ?>

                                </td>
                                <td class="text-center"><?php echo e(($crn == NULL) ? '-' : number_format($crn->amount_collected,2)); ?></td>
                                <td class="text-center"><?php echo e(($crn == NULL) ? '-' : number_format($crn->amount_deposited,2)); ?></td>
                                <td class="text-center"><?php echo e(($crn == NULL) ? '-' : number_format($crn->amount_paid,2)); ?></td>
                                <td class="text-center"><?php echo e(($crn == NULL) ? '-' : number_format($crn->balance,2)); ?></td>
                                <td class="text-center">
                                    <?php if($crn == NULL): ?>
                                        OPEN
                                    <?php else: ?>
                                        <?php if($crn->isPaid == 0): ?>
                                        COLLECTED
                                        <?php else: ?>
                                        PAID
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($crn == NULL): ?>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-secondary btn-sm"><i class="fa fa-wrench"></i></button>
                                        <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"><span class="visually-hidden">Toggle Dropdown</span>
                                        </button>
                                        <ul class="dropdown-menu">
                                            
                                                <?php if(Auth::user()->userlevel == 1 || Auth::user()->userlevel == 4): ?>
                                                <li>
                                                    <a class="dropdown-item" data-bs-target="#collect<?php echo e($csi->id); ?>" data-bs-toggle="modal">Collect Payment</a>
                                                </li>
                                                <?php endif; ?>
                                            
                                        </ul>
                                    </div>
                                    <?php else: ?>
                                    -
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="9" class="text-center">
                                    <?php if($crn != NULL): ?>
                                        <?php if($crn->img2 != NULL): ?>
                                        <img class="media-object" src="<?php echo asset('public/gl/'.$crn->img2); ?>" height="150" width="150">
                                        <?php else: ?>
                                        <p>No Receipt Image Available</p>       
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <p>No Receipt Image Available</p>   
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('modals'); ?>
<?php $__currentLoopData = $case->si_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $csi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $crn = \App\Case_collection::where('case_setup_id',$case->id)
            ->where('si_payment_id',$csi->id)
            ->first();
    
    $si_payment_detail = \App\Case_si_payment::where('id',$csi->id)->first();
    
    $receipt_type_num = \App\Payment_type_detail::where('id',$si_payment_detail->payment_type_detail_id)->first();

    if($receipt_type_num->receipt_type == 1){
        $rn = \App\Agent_receipt_payment::where('receipt_number',$csi->receipt_number)->where('receipt_type_id',$receipt_type_num->receipt_type)
            ->first();
    }elseif($receipt_type_num->receipt_type == 4){
        $rn = \App\Digital_receipt_payment::where('receipt_number',$csi->receipt_number)->where('receipt_type_id',$receipt_type_num->receipt_type)
            ->first();
    }elseif($receipt_type_num->receipt_type == 3){
        $rn = \App\SI_receipt_payment::where('receipt_number',$csi->receipt_number)->where('receipt_type_id',$receipt_type_num->receipt_type)
            ->first();
    }
?>
<?php echo Form::open(['method'=>'POST','action'=>['CaseController@store_crn',$case->id],'novalidate' => 'novalidate','files' => 'true']); ?>

<div class="modal fade" id="collect<?php echo e($csi->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Collect Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-12">
                        <center>
                            <div id="my_camera"></div>
                            <br/>
                            <input type=button value="Take Snapshot" onClick="take_snapshot()">
                            <input type="hidden" name="image" class="image-tag">
                        </center>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php if($rn != NULL): ?>
                            <?php if($receipt_type->receipt_type == 1 || $receipt_type->receipt_type == 4): ?>
                            <?php echo Form::label('Receipt #'); ?>

                            <?php echo Form::text('crn',$rn->receipt_number,['class'=>'form-control','readonly']); ?>

                            <?php else: ?>
                            <?php echo Form::label('CRN #'); ?>

                            <?php echo Form::text('crn',$rn->crn,['class'=>'form-control','readonly']); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            <?php echo Form::label('Receipt #'); ?>

                            <?php echo Form::text('crn',$csi->receipt_number,['class'=>'form-control','readonly']); ?>

                        <?php endif; ?>
                        <?php echo Form::hidden('si_payment_id',$csi->id,['class'=>'form-control']); ?>

                        <?php echo Form::hidden('remittances',$less + $mv - $voucher->less,['class'=>'form-control']); ?>

                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php echo Form::label('Total Amount Due'); ?>

                        <?php if($crn!= NULL && $crn->total_amount_due > 0): ?>
                        <?php echo Form::text('total_amount_due',$crn->total_amount_due,['class'=>'form-control','readonly']); ?>

                        <?php else: ?>
                        <?php echo Form::text('total_amount_due',$csi->si_amount,['class'=>'form-control','readonly']); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php echo Form::label('Amount Collected'); ?>

                        <?php if($crn != NULL): ?>
                        <?php echo Form::text('amount_collected',$crn->amount_collected,['class'=>'form-control']); ?>

                        <?php else: ?>
                        <?php echo Form::text('amount_collected','0.00',['class'=>'form-control']); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php echo Form::label('Amount Deposited'); ?>

                        <?php if($crn != NULL): ?>
                        <?php echo Form::text('amount_deposited',$crn->amount_deposited,['class'=>'form-control']); ?>

                        <?php else: ?>
                        <?php echo Form::text('amount_deposited','0.00',['class'=>'form-control']); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php echo Form::label('Remarks'); ?>

                        <?php if($crn != NULL): ?>
                        <?php echo Form::textarea('remarks',$crn->remarks,['class'=>'form-control']); ?>

                        <?php else: ?>
                        <?php echo Form::textarea('remarks',null,['class'=>'form-control']); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <?php if($crn != NULL): ?>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php echo Form::label('Amount Paid'); ?>

                        <?php echo Form::text('amount_paid',$crn->amount_paid,['class'=>'form-control']); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Collect Payment</button>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\agents\resources\views/admin/cases/create-payment.blade.php ENDPATH**/ ?>