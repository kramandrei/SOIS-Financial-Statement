
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Case Setup Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Case Setups</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <a href="<?php echo e(route('cases.create')); ?>" class="btn btn-primary mb-2"><i class="fa fa-plus-circle"></i> Create Entry</a>
            <a href="<?php echo e(route('cases.index')); ?>" class="btn btn-success mb-2"><i class="fa fa-retweet"></i> Reset</a>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <div class="row mb-3">
                    <div class="col-lg-2">
                        <form action="" method="GET" class="form-inline">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <select name="cstat" class="form-control single-select">
                                    <option value="">-- Select Status --</option>
                                    <option value="1">OPEN</option>
                                    <option value="2">DELIVERED</option>
                                    <option value="3">PULLED OUT</option>
                                    <option value="4">RECEIVABLE</option>
                                    <option value="6">COLLECTED</option>
                                    <option value="8">WITH BALANCE</option>
                                </select>
                            </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="form-group">
                            <select name="chosp" class="form-control single-select">
                                <option value="">-- Select Hospital --</option>
                                <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($h->id); ?>"><?php echo e($h->code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <select name="cpat" class="form-control single-select">
                                <option value="">-- Select Patient --</option>
                                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id); ?>"><?php echo e($p->FullName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="form-group">
                            <input type="date" name="cdate" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <button type="submit" class="btn btn-primary ml-2" style="margin-top:0px;">Search</button>
                        </form>
                    </div>
                </div>
                <table class="table table-striped" style="text-transform: uppercase;">
                    <thead>
                        <tr>
                            <th class="text-center">Status</th>
                            <th class="text-center">Date</th>
                            <th class="text-center">Branch</th>
                            <th class="text-center">Agent</th>
                            <th class="text-center">Hospital</th>
                            <th class="text-center">Implant</th>
                            <th class="text-center">Patient</th>
                            <th class="text-center" width="80">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if(Auth::user()->userlevel == 7){
                                if($d->tech_issued == 1){
                                    $status = 'PAID';
                                }else{
                                    $status = 'TO BE PAID';
                                }
                            }else{
                                if($d->caseStatus == 1){
                                    $status = 'OPEN';
                                }elseif($d->caseStatus == 2){
                                    $status = 'DELIVERED';
                                }elseif($d->caseStatus == 3){
                                    $status = 'PULLED OUT';
                                }elseif($d->caseStatus == 4){
                                    $status = 'RECEIVABLE';
                                }elseif($d->caseStatus == 5){
                                    $status = 'PAID';
                                }elseif($d->caseStatus == 6){
                                    $status = 'COLLECTED';
                                }elseif($d->caseStatus == 7){
                                    $status = 'CANCELLED';
                                }elseif($d->caseStatus == 8){
                                    $status = 'WITH BALANCE';
                                }else{
                                    $status = 'TO BE FIXED';
                                }
                            }

                            $checkDummy = \App\Case_patient_info::where('case_setup_id',$d->id)
                                ->first();
                            if($checkDummy != NULL){
                                $pname = $checkDummy->dummy_name;
                            }else{
                                $pname = $d->patient->FullName;
                            }

                            $check_vc = \App\Voucher::where('case_setup_id',$d->id)->first();
                            $er = \App\Case_er_entry::where('case_setup_id',$d->id)->first();
                        ?>
                        <tr>
                            <td><?php echo e($status); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($d->date_surgery)->toFormattedDateString()); ?></td>
                            <td><?php echo e($d->branch->code); ?></td>
                            <td><?php echo e($d->agent->code); ?></td>
                            <td><?php echo e(($d->hospital != NULL) ? $d->hospital->code : '-'); ?></td>
                            <td><?php echo e($d->implantcase->name); ?></td>
                            <td><?php echo e($pname); ?></td>
                            <td class="text-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary btn-sm"><i class="fa fa-wrench"></i></button>
                                    <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"><span class="visually-hidden">Toggle Dropdown</span>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <?php if($d->caseStatus == 1): ?>
                                                <a class="dropdown-item" href="<?php echo e(action('CaseController@edit', $d->id)); ?>">Edit Entry</a>
                                            <?php endif; ?>
                                                <a href="<?php echo e(action('CaseController@tech_view_list', $d->id)); ?>" class="dropdown-item">View Loaner Form</a>
                                                <a href="<?php echo e(action('CaseController@view_patient_info', $d->id)); ?>" class="dropdown-item">View Patient Info</a>
                                                <a href="<?php echo e(action('CaseController@view_receipt_info', $d->id)); ?>" class="dropdown-item">View Receipt Info</a>
                            
                                            <?php if($check_vc != NULL): ?>
                                                <a href="<?php echo e(action('CaseController@create_payment', $d->id)); ?>" class="dropdown-item">Create Payment</a>
                                            <?php endif; ?>
                            
                                            <?php if($d->caseStatus == 2 || $d->caseStatus == 3): ?>
                                                <a href="<?php echo e(action('CaseController@create_surgeon_rebates', $d->id)); ?>" class="dropdown-item">Add Surgeon Rebates</a>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>
</main>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bfmcv3\agents\resources\views/admin/cases/index.blade.php ENDPATH**/ ?>