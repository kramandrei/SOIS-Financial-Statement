
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Case Setup Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Case Setups</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <a href="<?php echo e(route('cases.create')); ?>" class="btn btn-primary mb-2"><i class="fa fa-plus-circle"></i> Create Entry</a>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <table class="table table-striped data-table" style="text-transform: uppercase;">
                    <thead>
                        <tr>
                            <th class="text-center">Status</th>
                            <th class="text-center">Date</th>
                            <th class="text-center">Branch</th>
                            <th class="text-center">Agent</th>
                            <th class="text-center">Hospital</th>
                            <th class="text-center">Implant</th>
                            <th class="text-center">Patient</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</main>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
  $(function () {
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('cases.index')); ?>",
        columns: [
            {data: 'status', name: 'status'},
            {data: 'date_surgery', name: 'date_surgery'},
            {data: 'branch_id', name: 'branch_id'},
            {data: 'agent_id', name: 'agent_id'},
            {data: 'hospital_id', name: 'hospital_id'},
            {data: 'case_id', name: 'case_id'},
            {data: 'patient_name', name: 'patient_name'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\agents\resources\views/admin/cases/index.blade.php ENDPATH**/ ?>