
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Case Setup Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('cases.index')); ?>">Case Setup</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Loaner Form Checklist</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mb-3">
        <div class="col-6">
            <?php if($case_setup_id->notes != NULL): ?>
            <div class="alert alert-success border-0 bg-success alert-dismissible fade show" style="text-transform:uppercase;">
                <h5 class="text-white">Note</h5>
                <hr>    
                <h5 style="color:white;"><?php echo e($case_setup_id->notes); ?></h5>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-6">
            <div class="alert alert-primary border-0 bg-primary alert-dismissible fade show" style="text-transform:uppercase;">
                <h5 class="text-white">Assigned Technician: <?php echo e(($case_setup_id->tech_id != NULL) ? $case_setup_id->technician->name : '-'); ?></h5>
                <hr>    
                <?php if($checkTechList > 0): ?>
                <h5 style="color:white;">Technician Pullout Report: DONE</h5>
                <?php else: ?>
                <h5 style="color:white;">Technician Pullout Report: MISSING</h5>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php echo Form::open(['method'=>'POST','action'=>['CaseController@store_tech_view_list',$case_setup_id]]); ?>

    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <div class="row mb-3">
                    <div class="col-12">
                        <table class="table table-striped mt-2" style="text-transform: uppercase;">
                            <thead>
                                <tr>
                                    <th class="text-center">Loaner Form Name</th>
                                    <th class="text-center">Product Code</th>
                                    <th class="text-center">Product Description</th>
                                    <th class="text-center" width="180">Qty to Deliver</th>
                                    <th class="text-center" width="180">Qty used</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getCheckList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $case_check_list = \App\Case_check_list::where('lf_id',$trow->id)->where('case_setup_id',$case_setup_id->id)->first();
                                    $case_tech_list = \App\Case_tech_list::where('lf_id',$trow->id)->where('case_setup_id',$case_setup_id->id)->first();
                                ?>
                                <tr>
                                    <td><?php echo e($trow->lflist->loanerform->name); ?></td>
                                    <td><?php echo e($trow->product->catalog_num); ?></td>
                                    <td>
                                        <?php echo Form::hidden('date_delivery[]',$case_setup_id->date_delivery,['class'=>'form-control','style'=>'text-align:center;']); ?>

                                        <?php echo Form::hidden('lf_id[]',$trow->id,['class'=>'form-control','style'=>'text-align:center;']); ?>

                                        <?php echo Form::hidden('product_id[]',$trow->product->id,['class'=>'form-control','style'=>'text-align:center;']); ?>

                                        <?php echo e($trow->product->description); ?>

                                    </td>
                                    <td>
                                        <?php echo e(number_format($trow->qty,0)); ?>

                                        <?php echo Form::hidden('qty[]',number_format($trow->qty,0),['class'=>'form-control','style'=>'text-align:center;','readonly']); ?>

                                    </td>
                                    <td>
                                        <?php if($case_tech_list != NULL ): ?>
                                        <?php echo Form::text('used[]',number_format($case_tech_list->used,0),['class'=>'form-control','style'=>'text-align:center;']); ?>

                                        <?php else: ?>
                                        <?php echo Form::text('used[]','0',['class'=>'form-control','style'=>'text-align:center;']); ?>

                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php if(Auth::user()->userlevel == 7): ?>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
        </div>
        <?php endif; ?>
    </div>
    <?php echo Form::close(); ?>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\agents\resources\views/admin/cases/tech-checklist.blade.php ENDPATH**/ ?>