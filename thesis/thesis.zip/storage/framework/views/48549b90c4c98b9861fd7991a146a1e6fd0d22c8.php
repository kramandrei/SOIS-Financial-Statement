<!--start sidebar -->
<aside class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
        <div>
            <img src="<?php echo e(asset('assets/images/logo-icon.png')); ?>" class="logo-icon" alt="logo icon">
        </div>
        <div>
            <h4 class="logo-text">BFMC</h4>
        </div>
        <div class="toggle-icon ms-auto"> <i class="bi bi-list"></i></div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">
        <li>
            <a href="<?php echo e(route('dashboard.index')); ?>">
                <div class="parent-icon"><i class="bi bi-house-fill"></i></div>
                <div class="menu-title">Dashboard</div>
            </a>
        </li>
        <li class="menu-label">Admin Setup</li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="fa fa-wrench"></i></div>
                <div class="menu-title">Settings</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('branches.index')); ?>"><i class="fa fa-building"></i>Branches</a>
                </li>
                <li>
                    <a href="<?php echo e(route('exchange-rates.index')); ?>"><i class="fa fa-user-shield"></i>Exchange Rates</a>
                </li>
                <li>
                    <a href="<?php echo e(route('system-settings.index')); ?>"><i class="fa fa-tools"></i>System Settings</a>
                </li>
                <li>
                    <a href="<?php echo e(route('tech-categories.index')); ?>"><i class="fa fa-user-shield"></i>Tech Categories</a>
                </li>
                <li>
                    <a href="<?php echo e(route('technicians.index')); ?>"><i class="fa fa-user-secret"></i>Technicians</a>
                </li>
                <li>
                    <a href="<?php echo e(route('usertypes.index')); ?>"><i class="fa fa-key"></i>Usertypes</a>
                </li>
            </ul>
        </li>
        <li class="menu-label">Accounting Setup</li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="fa fa-cash-register"></i></div>
                <div class="menu-title">Accounting</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('details.index')); ?>"><i class="fa fa-list-alt"></i>Details</a>
                </li>
                <li>
                    <a href="<?php echo e(route('expense-reports.index')); ?>"><i class="fa fa-money-bill-wave"></i>Expense Report</a>
                </li>
                <li>
                    <a href="<?php echo e(route('implant-cases.index')); ?>"><i class="fa fa-clipboard"></i>Loaner Forms</a>
                </li>
                <li>
                    <a href="<?php echo e(route('payment-types.index')); ?>"><i class="fa fa-credit-card"></i>Payment Types</a>
                </li>
                <li>
                    <a href="<?php echo e(route('payment-type-details.index')); ?>"><i class="fa fa-credit-card"></i>Payment Type Details</a>
                </li>
                <li>
                    <a href="<?php echo e(route('receipts.index')); ?>"><i class="fa fa-receipt"></i>Receipts</a>
                </li>
            </ul>
        </li>
        <li class="menu-label">Product Setup</li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="fa fa-cogs"></i></div>
                <div class="menu-title">Products</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('product-categories.index')); ?>"><i class="fa fa-list"></i>Categories</a>
                </li>
                <li>
                    <a href="<?php echo e(route('product-subone-categories.index')); ?>"><i class="fa fa-list"></i>Sub One Categories</a>
                </li>
                <li>
                    <a href="<?php echo e(route('product-subtwo-categories.index')); ?>"><i class="fa fa-list"></i>Sub Two Categories</a>
                </li>
            </ul>
        </li>
        <li class="menu-label">Setup</li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="fa fa-cogs"></i></div>
                <div class="menu-title">Utilities</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('agents.index')); ?>"><i class="fa fa-users"></i>Agents</a>
                </li>
                <li>
                    <a href="<?php echo e(route('hospitals.index')); ?>"><i class="fa fa-hospital"></i>Hospitals</a>
                </li>
                <li>
                    <a href="<?php echo e(route('other-expenses.index')); ?>"><i class="fa fa-wallet"></i>Other Expenses</a>
                </li>
                <li>
                    <a href="<?php echo e(route('other-settings.index')); ?>"><i class="fa fa-wrench"></i>Other Settings</a>
                </li>
                <li>
                    <a href="<?php echo e(route('stock-allowances.index')); ?>"><i class="fa fa-money-bill"></i>Stock Allowances</a>
                </li>
                <li>
                    <a href="<?php echo e(route('suppliers.index')); ?>"><i class="fa fa-bus"></i>Suppliers</a>
                </li>
                <li>
                    <a href="<?php echo e(route('surgeons.index')); ?>"><i class="fa fa-hospital"></i>Surgeons</a>
                </li>
                <li>
                    <a href="<?php echo e(route('vehicles.index')); ?>"><i class="fa fa-car"></i>Vehicles</a>
                </li>
            </ul>
        </li>
    </ul>
    <!--end navigation-->
</aside>
<!--end sidebar --><?php /**PATH C:\xampp\htdocs\bfmcv3\resources\views/layouts/partials/aside.blade.php ENDPATH**/ ?>