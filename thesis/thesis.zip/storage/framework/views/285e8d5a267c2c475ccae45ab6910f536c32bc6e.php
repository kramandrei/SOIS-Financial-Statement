
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Patient Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Patients</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <a class="btn btn-primary mb-2" href="<?php echo e(route('patients.create')); ?>"><i class="fa fa-plus-circle"></i> Create Entry</a>
            <a class="btn btn-success mb-2" href="<?php echo e(route('patients.index')); ?>"><i class="fa fa-retweet"></i> Reset</a>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <div class="row mb-3">
                    <div class="col-lg-4">
                        <form action="" method="GET" class="form-inline">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="text" name="lastname" placeholder="Enter Last Name" class="form-control">
                            </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <input type="text" name="firstname" placeholder="Enter First Name" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <button type="submit" class="btn btn-primary ml-2" style="margin-top:0px;">Search</button>
                        </form>
                    </div>
                </div>
                <table class="table table-striped" style="text-transform: uppercase;">
                    <thead>
                        <tr>
                            <th class="text-center">Patient ID</th>
                            <th class="text-center">Patient Name</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->patient_id); ?></td>
                            <td><?php echo e($d->FullName); ?></td>
                            <td class="text-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary btn-sm"><i class="fa fa-wrench"></i></button>
                                    <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"><span class="visually-hidden">Toggle Dropdown</span>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('patients.edit',$d->id)); ?>">Edit Entry</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('patients.quote-list',$d->id)); ?>">Create Quotation</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#delete'.$data->id.'" data-bs-toggle="modal">View History</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('patients.show-records',$d->id)); ?>">View Records</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('patients.remarks',$d->id)); ?>">View Remarks</a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>
</main>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bfmcv3\agents\resources\views/admin/patients/index.blade.php ENDPATH**/ ?>