<!--start sidebar -->
<aside class="sidebar-wrapper" data-simplebar="true">
    <div class="sidebar-header">
        <div>
            <h4 class="logo-text">BFMC</h4>
        </div>
        <div class="toggle-icon ms-auto"> <i class="bi bi-list"></i></div>
    </div>
    <!--navigation-->
    <ul class="metismenu" id="menu">
        <li>
            <a href="<?php echo e(route('dashboard.index')); ?>">
                <div class="parent-icon"><i class="bi bi-house-fill"></i></div>
                <div class="menu-title">Dashboard</div>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('dashboard.change-password',Auth::user()->id)); ?>">
                <div class="parent-icon"><i class="fa fa-key"></i></div>
                <div class="menu-title">Change Password</div>
            </a>
        </li>
        <li class="menu-label">Sales Setup</li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="fa fa-calendar"></i></div>
                <div class="menu-title">Daily Cases Setup</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('dashboard.case-now')); ?>"><i class="fa fa-tasks"></i> Today Cases</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="fa fa-wrench"></i></div>
                <div class="menu-title">Case Setup</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('cases.index')); ?>"><i class="fa fa-list"></i>Active Cases</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="fa fa-receipt"></i></div>
                <div class="menu-title">Receipt Module</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('agent-receipt-modules.index')); ?>"><i class="fa fa-receipt"></i>Agent Receipt</a>
                </li>
                <li>
                    <a href="<?php echo e(route('digital-receipt-modules.index')); ?>"><i class="fa fa-receipt"></i>Digital Receipt</a>
                </li>
                <li>
                    <a href="<?php echo e(route('si-receipt-modules.index')); ?>"><i class="fa fa-receipt"></i>SI Receipt</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('patients.index')); ?>">
                <div class="parent-icon"><i class="fa fa-users"></i></div>
                <div class="menu-title">Patients</div>
            </a>
        </li>
        <li>
            <a href="javascript:;" class="has-arrow">
                <div class="parent-icon"><i class="fa fa-cogs"></i></div>
                <div class="menu-title">Utilities</div>
            </a>
            <ul>
                <li>
                    <a href="<?php echo e(route('agents.index')); ?>"><i class="fa fa-users"></i>Agents</a>
                </li>
                <li>
                    <a href="<?php echo e(route('customer-leads.index')); ?>"><i class="fa fa-users"></i>Customer Leads</a>
                </li>
                <li>
                    <a href="<?php echo e(route('hospitals.index')); ?>"><i class="fa fa-hospital"></i>Hospitals</a>
                </li>
                </li>
                <li>
                    <a href="<?php echo e(route('surgeons.index')); ?>"><i class="fa fa-hospital"></i>Surgeons</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('gawas')); ?>">
                <div class="parent-icon"><i class="fa fa-sign-out-alt"></i></div>
                <div class="menu-title">Logout</div>
            </a>
        </li>
    </ul>
    <!--end navigation-->
</aside>
<!--end sidebar --><?php /**PATH D:\laragon\www\bfmcv3\agents\resources\views/layouts/partials/aside.blade.php ENDPATH**/ ?>