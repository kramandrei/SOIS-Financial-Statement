
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Patient Quotation Payment List Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('patients.index')); ?>">Patients Module</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('patients.quote-list',$quotation->patient_id)); ?>">Patients Quotation Module</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Patient Quotation Payments</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#addNew"><i class="fa fa-plus-circle"></i> Create Entry</button>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <table class="table table-striped table1" style="text-transform: uppercase;">
                    <thead>
                        <tr>
                            <th class="text-center">Date</th>
                            <th class="text-center">Payment Type</th>
                            <th class="text-center">Details</th>
                            <th class="text-center">Receipt Type</th>
                            <th class="text-center">Receipt Number</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Voucher #</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d[1]); ?></td>
                            <td><?php echo e($d[2]); ?></td>
                            <td><?php echo e($d[3]); ?></td>
                            <td><?php echo e($d[4]); ?></td>
                            <td><?php echo e($d[5]); ?></td>
                            <td><?php echo e($d[6]); ?></td>
                            <td><?php echo e($d[7]); ?></td>
                            <td><?php echo e($d[8]); ?></td>
                            <td class="text-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary btn-sm"><i class="fa fa-wrench"></i></button>
                                    <button type="button" class="btn btn-secondary dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"><span class="visually-hidden">Toggle Dropdown</span>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#refund<?php echo e($d[0]); ?>" data-bs-toggle="modal">Create Refund</a>
                                        </li>
                                        <?php
                                            $checkRefund = \App\Quotation_refund::where('qp_id',$d[0])->first();
                                            if($checkRefund != NULL){
                                                $allrs = \App\Attach_refund::where('refund_id',$checkRefund->id)->get();
                                            }
                                        ?>
                                        <?php if($checkRefund != NULL): ?>
                                            <li>
                                                <a class="dropdown-item" data-bs-target="#update-refund<?php echo e($d[0]); ?>" data-bs-toggle="modal">Edit Refund</a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" data-bs-target="#attach-refund<?php echo e($checkRefund->id); ?>" data-bs-toggle="modal">Upload Refund Slip</a>
                                            </li>
                                            <?php if($allrs->count() > 0): ?>
                                            <li>
                                                <a class="dropdown-item" data-bs-target="#allrs<?php echo e($checkRefund->id); ?>" data-bs-toggle="modal">View Refund Slips</a>
                                            </li>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#edit<?php echo e($d[0]); ?>" data-bs-toggle="modal">Edit Entry</a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#delete<?php echo e($d[0]); ?>" data-bs-toggle="modal">Delete Entry</a>
                                        </li>
                                        <?php if($d[9] == 1): ?>
                                        <li>
                                            <a class="dropdown-item" data-bs-target="#reset<?php echo e($d[0]); ?>" data-bs-toggle="modal">Reset Payment</a>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('modals'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
$qp = \App\Quotation_payment::find($d[0]);
?>
<div class="modal fade" id="edit<?php echo e($d[0]); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@update_quote_payment_list',$d[0]]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Update Payment</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="combo1" class="col-sm-3 col-form-label">Select Payment Type</label>
                                <div class="col-sm-9">
                                    <select name="payment_type_id" id="combo1" class="form-control select2-sm combo1">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pt->id); ?>"><?php echo e($pt->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo2" class="col-sm-3 col-form-label">Select Payment Detail</label>
                                <div class="col-sm-9">
                                    <select name="detail_id" id="combo2" class="form-control select2-sm combo2">
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo3" class="col-sm-3 col-form-label">Select Receipt Type</label>
                                <div class="col-sm-9">
                                    <select name="receipt_type_id" id="combo3" class="form-control select2-sm combo3">
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="discount_id" class="col-sm-3 col-form-label">Select Discount</label>
                                <div class="col-sm-9">
                                    <select name="discount_id" id="discount_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="charity" class="col-sm-3 col-form-label">Charity Institution</label>
                                <div class="col-sm-9">
                                    <input type="text" name="charity" class="form-control" id="charity" value="<?php echo e($qp->charity); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_number" class="col-sm-3 col-form-label">Receipt Number</label>
                                <div class="col-sm-9">
                                    <input type="text" name="receipt_number" class="form-control" id="receipt_number" value="<?php echo e($qp->receipt_number); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="gl_number" class="col-sm-3 col-form-label">GL Number</label>
                                <div class="col-sm-9">
                                    <input type="text" name="gl_number" class="form-control" id="gl_number" value="<?php echo e($qp->gl_number); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="si_amount" class="col-sm-3 col-form-label">Billed Amount (For SI only)</label>
                                <div class="col-sm-9">
                                    <input type="text" name="si_amount" class="form-control" id="si_amount" value="<?php echo e($qp->si_amount); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- DELETE -->
<div class="modal fade" id="delete<?php echo e($qp->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-danger">
            <div class="modal-header text-white">
                <h5 class="modal-title" id="exampleModalLabel">Delete Quotation Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-white">
                <p class="text-center">Are you sure you want to delete quotation payment entry?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                <a href="<?php echo e(action('PatientController@delete_quotation_payment',$qp->id)); ?>" class="btn btn-dark">Delete Entry</a>
            </div>
        </div>
    </div>
</div>
<!-- CREATE REFUND -->
<div class="modal fade" id="refund<?php echo e($qp->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@create_refund',$qp->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Create Refund</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="refund_amount" class="col-sm-3 col-form-label">Refund Amount</label>
                                <div class="col-sm-9">
                                    <input type="text" name="refund_amount" class="form-control" id="refund_amount" value="<?php echo e($qp->si_amount); ?>">
                                    <input type="hidden" name="date" class="form-control" id="date" value="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>">
                                    <input type="hidden" name="qp_id" class="form-control" id="qp_id" value="<?php echo e($qp->id); ?>">
                                    <input type="hidden" name="patient_id" class="form-control" id="patient_id" value="<?php echo e($quotation->patient_id); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- UPDATE REFUND -->
<?php 
    $editrefund = \App\Quotation_refund::where('qp_id',$qp->id)->first();
    if($editrefund != NULL){
        $eqr = $editrefund->refund_amount;
    }else{
        $eqr = 0;
    }
?>
<div class="modal fade" id="update-refund<?php echo e($qp->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@update_refund',$qp->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Update Refund</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="refund_amount" class="col-sm-3 col-form-label">Refund Amount</label>
                                <div class="col-sm-9">
                                    <input type="text" name="refund_amount" class="form-control" id="refund_amount" value="<?php echo e($eqr); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php if($checkRefund != NULL): ?>
<!-- UPLOAD REFUND SLIP -->
<div class="modal fade" id="attach-refund<?php echo e($checkRefund->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@attach_slip',$qp->id],'novalidate' => 'novalidate','files' => 'true']); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Upload Refund Slip</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="slip" class="col-sm-3 col-form-label">Attach Slip</label>
                                <div class="col-sm-9">
                                    <input type="file" name="slip" class="form-control" id="slip">
                                    <input type="hidden" name="refund_id" class="form-control" id="refund_id" value="<?php echo e($checkRefund->id); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- VIEW UPLOAD REFUND SLIP -->
<div class="modal fade" id="allrs<?php echo e($checkRefund->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Upload Refund Slip</h5>
                            </div>
                            <hr>
                            <table class="table table-bordered">
                                <tbody>
                                    <?php $__currentLoopData = $allrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <img class="media-object" src="<?php echo asset('/gl/'.$a->slip); ?>" height="150" width="150">
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<!-- RESET PAYMENT -->
<div class="modal fade" id="reset<?php echo e($qp->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-danger">
            <div class="modal-header text-white">
                <h5 class="modal-title" id="exampleModalLabel">Reset Quotation Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-white">
                <p class="text-center">Are you sure you want to reset quotation payment entry?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                <a href="<?php echo e(action('PatientController@reset_payment',$qp->id)); ?>" class="btn btn-dark">Reset Payment</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="addNew" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['PatientController@store_quote_payment_list',$quotation->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Create New Payment</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="combo1" class="col-sm-3 col-form-label">Select Payment Type</label>
                                <div class="col-sm-9">
                                    <select name="payment_type_id" id="combo1" class="form-control select2-sm combo1">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pt->id); ?>"><?php echo e($pt->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo2" class="col-sm-3 col-form-label">Select Payment Detail</label>
                                <div class="col-sm-9">
                                    <select name="detail_id" id="combo2" class="form-control select2-sm combo2">
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo3" class="col-sm-3 col-form-label">Select Receipt Type</label>
                                <div class="col-sm-9">
                                    <select name="receipt_type_id" id="combo3" class="form-control select2-sm combo3">
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="discount_id" class="col-sm-3 col-form-label">Select Discount</label>
                                <div class="col-sm-9">
                                    <select name="discount_id" id="discount_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="charity" class="col-sm-3 col-form-label">Charity Institution</label>
                                <div class="col-sm-9">
                                    <input type="text" name="charity" class="form-control" id="charity">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_number" class="col-sm-3 col-form-label">Receipt Number</label>
                                <div class="col-sm-9">
                                    <input type="text" name="receipt_number" class="form-control" id="receipt_number">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="gl_number" class="col-sm-3 col-form-label">GL Number</label>
                                <div class="col-sm-9">
                                    <input type="text" name="gl_number" class="form-control" id="gl_number">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="si_amount" class="col-sm-3 col-form-label">Billed Amount (For SI only)</label>
                                <div class="col-sm-9">
                                    <input type="text" name="si_amount" class="form-control" id="si_amount">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var payment_type_id = $('.combo1').val();
    var detail_id = $('.combo2').val(); 

    $.ajax({    //create an ajax request to load_page.php
        type: 'GET',
        url: "<?php echo e(action('PaymentTypeDetailController@loaddetails')); ?>",//php file url diri     
        dataType: "json",    
        data: { combobox1 : payment_type_id },
        success: function(response){
            $(".combo2").append('<option value=""> -- Select One --</option>');
            $.each(response,function(index,value){
                $(".combo2").append('<option value="'+value.id+'">'+value.name+'</option>');
          
            });            
        }
    });

    $('.combo1').change(function() {
        var combobox1 = $(this).val(); 
       $(".combo2").html("");
        $.ajax({    //create an ajax request to load_page.php
            type: 'GET',
            url: "<?php echo e(action('PaymentTypeDetailController@loaddetails')); ?>",//php file url diri     
            dataType: "json",    
            data: { combobox1 : combobox1 },
            success: function(response){
                $(".combo2").append('<option value=""> -- Select One --</option>')
                $.each(response,function(index,value){
                    $(".combo2").append('<option value="'+value.id+'">'+value.name+'</option>');
              
                });
            }
        });
    });

    $.ajax({    //create an ajax request to load_page.php
        type: 'GET',
        url: "<?php echo e(action('PaymentTypeDetailController@loadreceipts')); ?>",//php file url diri     
        dataType: "json",    
        data: { combobox2 : detail_id, combobox1: payment_type_id },
        success: function(response){
            $(".combo3").append('<option value=""> -- Select One --</option>');
            $.each(response,function(index,value){
                $(".combo3").append('<option value="'+value.id+'">'+value.name+'</option>');
          
            });            
        }
    });

    $('.combo2').change(function() {
        var combobox2 = $(this).val();
        var payment_type_id = $('.combo1').val();
        console.log(combobox2); 
        $(".combo3").html("");
        $.ajax({    //create an ajax request to load_page.php
            type: 'GET',
            url: "<?php echo e(action('PaymentTypeDetailController@loadreceipts')); ?>",//php file url diri     
            dataType: "json",    
            data: { combobox2 : combobox2, payment_type_id: payment_type_id },
            success: function(response){
                $(".combo3").append('<option value=""> -- Select One --</option>');
                $.each(response,function(index,value){
                    $(".combo3").append('<option value="'+value.id+'">'+value.name+'</option>');
              
                });
            }
        });
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\agents\resources\views/admin/patients/quotation-payment-list.blade.php ENDPATH**/ ?>