
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Digital Receipt Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('agent-receipt-modules.index')); ?>">Digital Receipt Module</a></li>
                    <li class="breadcrumb-item active" aria-current="page">DR Payment List - <span style="color:blue; text-transform: uppercase;font-weight: bold;"><?php echo e($receipt->user->name); ?>[<?php echo e($receipt->control_from); ?> - <?php echo e($receipt->control_to); ?>]</span></li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#addNew"><i class="fa fa-plus-circle"></i> Create Payment</button>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <table class="table table-striped data-table" style="text-transform: uppercase;">
                    <thead>
                        <tr>
                            <th class="text-center">Date</th>
                            <th class="text-center">Payable To</th>
                            <th class="text-center">Patient</th>
                            <th class="text-center">Implant</th>
                            <th class="text-center">Agent</th>
                            <th class="text-center">Receipt</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</main>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('modals'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit<?php echo e($d->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'PATCH','action'=>['DigitalReceiptModuleController@update_payment',$d->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Update Payment: <?php echo e($d->patient_name); ?></h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="date" class="col-sm-3 col-form-label">Date</label>
                                <div class="col-sm-9">
                                    <input type="date" name="date" class="form-control" id="date" value="<?php echo e($d->date); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="payable" class="col-sm-3 col-form-label">Payable To</label>
                                <div class="col-sm-9">
                                    <input type="text" name="payable" class="form-control" id="payable" value="<?php echo e($d->payable); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="patient_name" class="col-sm-3 col-form-label">Patient Name</label>
                                <div class="col-sm-9">
                                    <input type="text" name="patient_name" class="form-control" id="patient_name" value="<?php echo e($d->patient_name); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="implant" class="col-sm-3 col-form-label">Implant</label>
                                <div class="col-sm-9">
                                    <input type="text" name="implant" class="form-control" id="implant" value="<?php echo e($d->implant); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="agent_id" class="col-sm-3 col-form-label">Select Agent</label>
                                <div class="col-sm-9">
                                    <select name="agent_id" id="agent_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($a->id); ?>" <?php echo e(($d->agent_id == $a->id) ? 'selected' : ''); ?>><?php echo e($a->code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="hospital_id" class="col-sm-3 col-form-label">Select Hospital</label>
                                <div class="col-sm-9">
                                    <select name="hospital_id" id="hospital_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($h->id); ?>" <?php echo e(($d->hospital_id == $h->id) ? 'selected' : ''); ?>><?php echo e($h->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="surgeon_id" class="col-sm-3 col-form-label">Select Surgeon</label>
                                <div class="col-sm-9">
                                    <select name="surgeon_id" id="surgeon_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $surgeons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->id); ?>" <?php echo e(($d->surgeon_id == $s->id) ? 'selected' : ''); ?>><?php echo e($s->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_type_id" class="col-sm-3 col-form-label">Select Receipt Type</label>
                                <div class="col-sm-9">
                                    <select name="receipt_type_id" id="receipt_type_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id); ?>" <?php echo e(($d->receipt_type_id == $r->id) ? 'selected' : ''); ?>><?php echo e($r->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_number" class="col-sm-3 col-form-label">Receipt Number</label>
                                <div class="col-sm-9">
                                    <input type="text" name="receipt_number" class="form-control" id="receipt_number" value="<?php echo e($d->receipt_number); ?>" readonly>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="amount" class="col-sm-3 col-form-label">Amount</label>
                                <div class="col-sm-9">
                                    <input type="text" name="amount" class="form-control" id="amount" value="<?php echo e($d->amount); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- DELETE -->
<div class="modal fade" id="delete<?php echo e($d->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-danger">
            <div class="modal-header text-white">
                <h5 class="modal-title" id="exampleModalLabel">Delete Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-white">
                <p class="text-center">Are you sure you want to delete payment entry?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                <a href="<?php echo e(action('DigitalReceiptModuleController@delete_payment',$d->id)); ?>" class="btn btn-dark">Delete Entry</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="addNew" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['DigitalReceiptModuleController@store_payment',$receipt->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Create Payment</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="date" class="col-sm-3 col-form-label">Date</label>
                                <div class="col-sm-9">
                                    <input type="date" name="date" class="form-control" id="date">
                                    <input type="hidden" name="user_id" class="form-control" id="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                    <input type="hidden" name="dr_receipt_id" class="form-control" id="dr_receipt_id" value="<?php echo e($receipt->id); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="payable" class="col-sm-3 col-form-label">Payable To</label>
                                <div class="col-sm-9">
                                    <input type="text" name="payable" class="form-control" id="payable">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="patient_name" class="col-sm-3 col-form-label">Patient Name</label>
                                <div class="col-sm-9">
                                    <input type="text" name="patient_name" class="form-control" id="patient_name">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="implant" class="col-sm-3 col-form-label">Implant</label>
                                <div class="col-sm-9">
                                    <input type="text" name="implant" class="form-control" id="implant">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="agent_id" class="col-sm-3 col-form-label">Select Agent</label>
                                <div class="col-sm-9">
                                    <select name="agent_id" id="agent_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($a->id); ?>"><?php echo e($a->code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="hospital_id" class="col-sm-3 col-form-label">Select Hospital</label>
                                <div class="col-sm-9">
                                    <select name="hospital_id" id="hospital_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($h->id); ?>"><?php echo e($h->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="surgeon_id" class="col-sm-3 col-form-label">Select Surgeon</label>
                                <div class="col-sm-9">
                                    <select name="surgeon_id" id="surgeon_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $surgeons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_type_id" class="col-sm-3 col-form-label">Select Receipt Type</label>
                                <div class="col-sm-9">
                                    <select name="receipt_type_id" id="receipt_type_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id); ?>"><?php echo e($r->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_number" class="col-sm-3 col-form-label">Receipt Number</label>
                                <div class="col-sm-9">
                                    <input type="text" name="receipt_number" class="form-control" id="receipt_number" value="<?php echo e($cn); ?>" readonly>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="amount" class="col-sm-3 col-form-label">Amount</label>
                                <div class="col-sm-9">
                                    <input type="text" name="amount" class="form-control" id="amount">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
  $(function () {
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('digital-receipt-modules.index_payment',$receipt->id)); ?>",
        columns: [
            {data: 'date', name: 'date'},
            {data: 'payable', name: 'payable'},
            {data: 'patient_name', name: 'patient_name'},
            {data: 'implant', name: 'implant'},
            {data: 'agent_id', name: 'agent_id'},
            {data: 'receipt_type_id', name: 'receipt_type_id'},
            {data: 'amount', name: 'amount'},
            {data: 'status', name: 'status'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\agents\resources\views/admin/digital-receipt-modules/index-payment.blade.php ENDPATH**/ ?>