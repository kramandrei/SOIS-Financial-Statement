
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Case Setup Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('cases.index')); ?>">Case Setups</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create Receipt Information of <?php echo e($case->patient->FullName); ?></li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mb-3">
        <div class="col-12">
            <div class="alert alert-success border-0 bg-success alert-dismissible fade show" style="text-transform:uppercase;">
                <?php if($case->technician == NULL): ?>
                <h5 class="text-white">Tech Assigned: N/A</h5>
                <?php else: ?>
                <h5 class="text-white">Tech Assigned: <?php echo e($case->technician->name); ?></h5>
                <?php endif; ?>                
                <hr>
                <?php if($patientcheck != NULL): ?>    
                <h5 style="color:white;">Receipt #: <?php echo e($patientcheck->payment_detail->detail->name); ?> <?php echo e($patientcheck->payment_detail->receipt->name); ?>- <?php echo e($patientcheck->receipt_number); ?></h5>
                <h5 style="color:white;">Receipt Owner: <?php echo e($owner); ?></h5>
                <?php endif; ?>
            </div>
        </div>
        
    </div>
    <?php echo Form::open(['method'=>'POST','action'=>['CaseController@update_receipt_info',$case->id],'autocomplete'=>'off']); ?>

    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <div class="row mb-3">
                    <div class="col-12">
                        <?php echo Form::label('','Select Receipt Type'); ?>

                        <?php if($trp != NULL): ?>
                        <?php echo Form::select('receipt_type_id',$receipts,$trp->receipt_type_id,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>

                        <?php else: ?>
                        <?php echo Form::select('receipt_type_id',$receipts,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <?php echo Form::label('','Enter Receipt #'); ?>

                        <?php if($trp != NULL): ?>
                        <?php echo Form::text('receipt_number',$trp->receipt_number,['class'=>'form-control']); ?>

                        <?php else: ?>
                        <?php echo Form::text('receipt_number',null,['class'=>'form-control']); ?>

                        <?php endif; ?>
                        <?php echo Form::hidden('patient_id',$case->patient_name,['class'=>'form-control']); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <?php if(Auth::user()->userlevel == 7): ?>
            <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
            <?php endif; ?>
        </div>
    </div>
    <?php echo Form::close(); ?>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bfmcv3\agents\resources\views/admin/cases/receipt-info.blade.php ENDPATH**/ ?>