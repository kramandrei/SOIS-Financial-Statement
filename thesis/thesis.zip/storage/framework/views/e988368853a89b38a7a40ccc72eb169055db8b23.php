
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Organizational Income Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('org-incomes.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create Organizational Income</li>
                </ol>
            </nav>
        </div>
    </div>
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::open(['method'=>'POST','action'=>'OrgIncomeController@store','novalidate' => 'novalidate','files' => 'true']); ?>

    <div class="card">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-4">
                    <div class="form-group">
                        <?php echo Form::label('Date: '); ?>

                        <?php echo Form::date('date',\Carbon\Carbon::now()->toDateString(),['class'=>'form-control']); ?>

                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <?php echo Form::label('Upload Receipt: '); ?><br>
                        <?php echo Form::file('receipt',null,['class'=>'form-control']); ?>

                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-4">
                    <div class="form-group">
                        <?php echo Form::label('Select Category: '); ?>

                        <?php echo Form::select('income_id',$incomes,null,['class'=>'form-control single-select','placeholder'=>'--Select One--']); ?>

                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <?php echo Form::label('OR #: '); ?>

                        <?php echo Form::text('invoice_or',null,['class'=>'form-control']); ?>

                    </div>
                </div>
                <div class="col-4">
                    <div class="form-group">
                        <?php echo Form::label('Amount: '); ?>

                        <?php echo Form::text('amount','0.00',['class'=>'form-control']); ?>

                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="form-group">
                        <?php echo Form::label('Description: '); ?>

                        <?php echo Form::textarea('description',null,['class'=>'form-control']); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
    </div>
    <?php echo Form::close(); ?>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\project_thesis\resources\views/admin/org-incomes/create.blade.php ENDPATH**/ ?>