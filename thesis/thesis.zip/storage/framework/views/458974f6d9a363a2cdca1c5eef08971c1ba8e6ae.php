
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Implant Case Module: <span style="color:blue;font-weight: bold; text-transform: uppercase;"><?php echo e($subcase->case->name); ?> | <?php echo e($subcase->name); ?></span></div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('implant-cases.index')); ?>">Implant Cases</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('implant-cases.view-sub-cases',$subcase->case_id)); ?>">Implant Sub Cases</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Loaner Form List</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#addNew"><i class="fa fa-plus-circle"></i> Create Entry</button>
            <a href="#" class="btn btn-success mb-2"><i class="fa fa-print"></i> Print Loaner Form</a>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <table class="table table-striped data-table" style="text-transform: uppercase; font-size:11px;">
                    <thead>
                        <tr>
                            <th class="text-center">Name</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit<?php echo e($d->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['ImplantCaseController@update_loaner_forms',$d->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Update Loaner Form: <?php echo e($d->name); ?></h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="name" class="col-sm-3 col-form-label">Name</label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" class="form-control" id="name" value="<?php echo e($d->name); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo1" class="col-sm-3 col-form-label">Select Product Category</label>
                                <div class="col-sm-9">
                                    <select name="category_id" id="combo1" class="form-control select2-sm combo1">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo2" class="col-sm-3 col-form-label">Select Sub One Category</label>
                                <div class="col-sm-9">
                                    <select class="form-control select2-sm combo2" name="subone_id" id="combo2">                     
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo3" class="col-sm-3 col-form-label">Select Sub Two Category</label>
                                <div class="col-sm-9">
                                    <select class="form-control select2-sm combo3" name="subtwo_id" id="combo3">                     
                                    </select>       
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <table class="table table-bordered" id="prodtable">
                                        <thead>
                                            <tr>
                                                <th class="text-center" width="50"><i class="icon-check"></i></th>
                                                <th class="text-center">Catalog Num</th>
                                                <th class="text-center">Product Description</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<div class="modal fade" id="view<?php echo e($d->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Loaner Form List Items of <?php echo e($d->name); ?></h5>
                            </div>
                            <hr>
                            <table class="table table-striped" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Catalog</th>
                                        <th class="text-center">Name</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $d->lflist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dlf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($dlf->product->catalog_num); ?></td>
                                        <td><?php echo e($dlf->product->description); ?></td>
                                        <td class="text-center">
                                            <a data-bs-target="#delete<?php echo e($dlf->id); ?>" data-bs-toggle="modal" data-bs-dismiss="modal" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <div class="modal fade" id="delete<?php echo e($dlf->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-fullscreen">
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="border p-4 rounded">
                                                                <div class="card-title d-flex align-items-center">
                                                                    <h5 class="mb-0">
                                                                        Are you sure you want to delete this entry?
                                                                        <span style="color:blue;font-weight: bold; text-transform: uppercase;"><?php echo e($dlf->product->catalog_num); ?> | <?php echo e($dlf->product->description); ?></span>
                                                                    </h5>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-success" data-bs-target="view<?php echo e($d->id); ?>" data-bs-toggle="modal" data-bs-dismiss="modal">Back to Loaner Form List Items</button>
                                                    <a href="<?php echo e(route('implant-cases.delete-lfi',$dlf->id)); ?>" class="btn btn-danger">Delete Entry</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="addNew" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>['ImplantCaseController@store_loaner_forms',$subcase->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Create Loaner Form</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="name" class="col-sm-3 col-form-label">Name</label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" class="form-control" id="name">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo1" class="col-sm-3 col-form-label">Select Product Category</label>
                                <div class="col-sm-9">
                                    <select name="category_id" id="combo1" class="form-control select2-sm combo1">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo2" class="col-sm-3 col-form-label">Select Sub One Category</label>
                                <div class="col-sm-9">
                                    <select class="form-control select2-sm combo2" name="subone_id" id="combo2">                     
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="combo3" class="col-sm-3 col-form-label">Select Sub Two Category</label>
                                <div class="col-sm-9">
                                    <select class="form-control select2-sm combo3" name="subtwo_id" id="combo3">                     
                                    </select>       
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <table class="table table-bordered" id="prodtable">
                                        <thead>
                                            <tr>
                                                <th class="text-center" width="50"><i class="icon-check"></i></th>
                                                <th class="text-center">Catalog Num</th>
                                                <th class="text-center">Product Description</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
  $(function () {
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('implant-cases.view-loaner-forms',$subcase->id)); ?>",
        columns: [
            {data: 'name', name: 'name'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>
<script>
    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
    });

    var category_id = $('.combo1').val();
    var subone_id = $('.combo2').val(); 

    $.ajax({    //create an ajax request to load_page.php
        type: 'GET',
        url: "<?php echo e(action('ProductController@loadsubone')); ?>",//php file url diri     
        dataType: "json",    
        data: { combobox1 : category_id },
        success: function(response){
            $(".combo2").append('<option value=""> -- Select One --</option>');
            $.each(response,function(index,value){
                $(".combo2").append('<option value="'+value.id+'">'+value.name+'</option>');
          
           });            
        }
    });

    $('.combo1').change(function() {
        var combobox1 = $(this).val(); 
       $(".combo2").html("");
        $.ajax({    //create an ajax request to load_page.php
            type: 'GET',
            url: "<?php echo e(action('ProductController@loadsubone')); ?>",//php file url diri     
            dataType: "json",    
            data: { combobox1 : combobox1 },
            success: function(response){
                $(".combo2").append('<option value=""> -- Select One --</option>')
                $.each(response,function(index,value){
                    $(".combo2").append('<option value="'+value.id+'">'+value.name+'</option>');
              
               });
            }
        });
    });

    $.ajax({    //create an ajax request to load_page.php
        type: 'GET',
        url: "<?php echo e(action('ProductController@loadsubtwo_lf')); ?>",//php file url diri     
        dataType: "json",    
        data: { combobox2 : subone_id },
        success: function(response){
            $(".combo3").append('<option value=""> -- Select One --</option>');
            $.each(response,function(index,value){
                $(".combo3").append('<option value="'+value.id+'">'+value.name+'</option>');
          
           });            
        }
    });

    $('.combo2').change(function() {
        var combobox2 = $(this).val(); 
       $(".combo3").html("");
        $.ajax({    //create an ajax request to load_page.php
            type: 'GET',
            url: "<?php echo e(action('ProductController@loadsubtwo_lf')); ?>",//php file url diri     
            dataType: "json",    
            data: { combobox2 : combobox2 },
            success: function(response){
                $(".combo3").append('<option value=""> -- Select One --</option>');
                $.each(response,function(index,value){
                    $(".combo3").append('<option value="'+value.id+'">'+value.name+'</option>');
              
               });
            }
        });
    });

    $('.combo3').change(function() {
        var combobox3 = $(this).val(); 
        $.ajax({    //create an ajax request to load_page.php
            type: 'GET',
            url: "<?php echo e(action('ProductController@loadproducts')); ?>",//php file url diri     
            dataType: "json",    
            data: { combobox3 : combobox3 },
            success: function(response){
                $("#prodtable tbody").html("");
                $.each(response,function(index,value){
                    data = '<tr>';
                    data += '<td align="center"><input type="checkbox" name="product_id[]" value="'+value.id+'" "class"="form-control"></td>';
                    data += '<td>'+value.catalog_num+'</td>';
                    data += '<td>'+value.description+'</td>';
                    data += '</tr>';
                    $("#prodtable tbody").append(data);
                
                });
            }
        });
    });

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\resources\views/admin/implant-cases/view-loaner-forms.blade.php ENDPATH**/ ?>