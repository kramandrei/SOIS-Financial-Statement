
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Payment Type Detail Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Payment Type Details</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#addNew"><i class="fa fa-plus-circle"></i> Create Entry</button>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <table class="table table-striped data-table" style="text-transform: uppercase; font-size:11px;">
                    <thead>
                        <tr>
                            <th class="text-center">Payment Type</th>
                            <th class="text-center">Detail</th>
                            <th class="text-center">Receipt</th>
                            <th class="text-center">WTAX</th>
                            <th class="text-center">VAT</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</main>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('modals'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit<?php echo e($d->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'PATCH','action'=>['PaymentTypeDetailController@update',$d->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Update Payment Type Detail: <?php echo e($d->paymenttype->name); ?> | <?php echo e($d->detail->name); ?> | <?php echo e($d->receipt->name); ?></h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="payment_type_id" class="col-sm-3 col-form-label">Select Payment Type</label>
                                <div class="col-sm-9">
                                    <select name="payment_type_id" id="payment_type_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pt->id); ?>" <?php echo e(($d->payment_type_id == $pt->id) ? 'selected' : ''); ?>><?php echo e($pt->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="details" class="col-sm-3 col-form-label">Select Detail</label>
                                <div class="col-sm-9">
                                    <select name="details" id="details" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dt->id); ?>" <?php echo e(($d->details == $dt->id) ? 'selected' : ''); ?>><?php echo e($dt->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_type" class="col-sm-3 col-form-label">Select Receipt</label>
                                <div class="col-sm-9">
                                    <select name="receipt_type" id="receipt_type" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id); ?>" <?php echo e(($d->receipt_type == $r->id) ? 'selected' : ''); ?>><?php echo e($r->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="wh" class="col-sm-3 col-form-label">WTAX</label>
                                <div class="col-sm-9">
                                    <input type="text" name="wh" class="form-control" id="wh" value="<?php echo e($d->wh); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="vat" class="col-sm-3 col-form-label">VAT</label>
                                <div class="col-sm-9">
                                    <input type="text" name="vat" class="form-control" id="vat" value="<?php echo e($d->vat); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="addNew" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>'PaymentTypeDetailController@store']); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Create Payment Type Detail</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="payment_type_id" class="col-sm-3 col-form-label">Select Payment Type</label>
                                <div class="col-sm-9">
                                    <select name="payment_type_id" id="payment_type_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($pt->id); ?>"><?php echo e($pt->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="details" class="col-sm-3 col-form-label">Select Detail</label>
                                <div class="col-sm-9">
                                    <select name="details" id="details" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dt->id); ?>"><?php echo e($dt->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="receipt_type" class="col-sm-3 col-form-label">Select Receipt</label>
                                <div class="col-sm-9">
                                    <select name="receipt_type" id="receipt_type" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id); ?>"><?php echo e($r->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="wh" class="col-sm-3 col-form-label">WTAX</label>
                                <div class="col-sm-9">
                                    <input type="text" name="wh" class="form-control" id="wh" value="0.00">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="vat" class="col-sm-3 col-form-label">VAT</label>
                                <div class="col-sm-9">
                                    <input type="text" name="vat" class="form-control" id="vat" value="0.00">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
  $(function () {
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('payment-type-details.index')); ?>",
        columns: [
            {data: 'payment_type_id', name: 'payment_type_id'},
            {data: 'details', name: 'details'},
            {data: 'receipt_type', name: 'receipt_type'},
            {data: 'wh', name: 'wh'},
            {data: 'vat', name: 'vat'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\resources\views/admin/payment-type-details/index.blade.php ENDPATH**/ ?>