
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Case Setup Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('cases.index')); ?>">Case Setups</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create Case Setup</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo Form::open(['method'=>'POST','action'=>'CaseController@store','autocomplete'=>'off']); ?>

    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <div class="row mb-3">
                    <div class="col-4">
                        <label for="date" class="form-label">Date</label>
                        <input type="date" name="date" class="form-control" id="date" value="">
                    </div>
                    <div class="col-4">
                        <label for="patient_name" class="form-label">Select Patient</label>     
                        <?php echo Form::select('patient_name',$patients,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>

                    </div>
                    <div class="col-4">
                        <label for="branch_id" class="form-label">Select Branch</label>
                        <?php echo Form::select('branch_id',$branches,Auth::user()->branch_id,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>       
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-4">
                        <label for="agent_id" class="form-label">Select Agent</label>     
                        <?php echo Form::select('agent_id',$agents,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>

                    </div>
                    <div class="col-4">
                        <label for="surgeon_id" class="form-label">Select Surgeon</label>
                        <?php echo Form::select('surgeon_id',$surgeons,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>       
                    </div>
                    <div class="col-4">
                        <label for="time" class="form-label">Time</label>
                        <input type="time" name="time" class="form-control" id="time">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-6">
                        <label for="hospital_id" class="form-label">Select Hospital</label>     
                        <?php echo Form::select('hospital_id',$hospitals,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>

                    </div>
                    <div class="col-6">
                        <label for="case_id" class="form-label">Select Implant Case</label>
                        <?php echo Form::select('case_id',$implant_cases,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --','id'=>'combo1']); ?>       
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-12">
                        <label for="subcase_id" class="form-label">Select Subcases</label>     
                        <select class="single-select form-control" name="subcase_id[]" id="combo2" multiple="multiple"></select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-2">
                        <div class="form-group">
                            <?php echo Form::label('','Select AutoClave Type'); ?>

                            <?php echo Form::select('autoclave_type',['1'=>'INSIDE','2'=>'OUTSIDE'],null,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>

                            <input type="checkbox" name="ac_out" value="1" class="mt-1"> Add Autoclave OUT
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-group">
                            <?php echo Form::label('','Enter Cycle'); ?>

                            <?php echo Form::text('cycle','0',['class'=>'form-control','autocomplete'=>'off']); ?>

                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('','Date of Delivery'); ?>

                            <input type="date" name="date_delivery" class="form-control" id="date">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('','Date of Surgery'); ?>

                            <input type="date" name="date_surgery" class="form-control" id="date">
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('','Select Receipt'); ?>

                            <?php echo Form::select('receipt',$receipts,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>

                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('','Select Detail'); ?>

                            <?php echo Form::select('detail_id',$details,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --']); ?>

                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('','Qty of Receipt'); ?>

                            <?php echo Form::text('qty_receipt',null,['class'=>'form-control','autocomplete'=>'off']); ?>

                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <div class="form-group">
                            <?php echo Form::label('','Notes'); ?>

                            <?php echo Form::textarea('notes',null,['class'=>'form-control']); ?>

                        </div>
                    </div>
                </div>
                <hr>
                <p>Transportation Details</p>
                <div class="row mb-3">
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('','Select Category'); ?>

                            <?php echo Form::select('category_id',['FETCH'=>'FETCH','PERSONAL'=>'PERSONAL','COMPANY'=>'COMPANY'],null,['class'=>'single-select form-control','placeholder'=>'-- Select One --','id'=>'cat']); ?>

                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('','Select Choice'); ?><small style="margin-left:10px;">For Personal/Company Category Only</small>
                            <?php echo Form::select('choice',['CAR'=>'CAR','MOTOR'=>'MOTOR'],null,['class'=>'single-select form-control','placeholder'=>'-- Select One --','id'=>'choice']); ?>

                        </div>
                    </div>
                    <div class="col-4">
                        <div class="form-group">
                            <?php echo Form::label('','Select Vehicle'); ?>

                            <?php echo Form::select('vehicle_id',$vehicles,null,['class'=>'single-select form-control','placeholder'=>'-- Select One --','id'=>'vehicle']); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-primary mt-2">Save Changes</button>
        </div>
    </div>
    <?php echo Form::close(); ?>

</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
    });

    var case_id = $('#combo1').val();

    $.ajax({    //create an ajax request to load_page.php
        type: 'GET',
        url: "<?php echo e(action('CaseController@loadsubcases')); ?>",//php file url diri     
        dataType: "json",    
        data: { combobox1 : case_id },
        success: function(response){
            //$("#combo2").append('<option value="">PLEASE SELECT</option>');
            $.each(response,function(index,value){
                $("#combo2").append('<option value="'+value.id+'">'+value.name+'</option>');
          
           });            
        }
    });

    $('#combo1').change(function() {
        var combobox1 = $(this).val(); 
       $("#combo2").html("");
        $.ajax({    //create an ajax request to load_page.php
            type: 'GET',
            url: "<?php echo e(action('CaseController@loadsubcases')); ?>",//php file url diri     
            dataType: "json",    
            data: { combobox1 : combobox1 },
            success: function(response){
                //$("#combo2").append('<option value="">PLEASE SELECT</option>')
                $.each(response,function(index,value){
                    $("#combo2").append('<option value="'+value.id+'">'+value.name+'</option>');
              
               });
            }
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#cat").change(function () {
            var val = $(this).val();

            if (val == "FETCH") {
                $("#choice").prop('disabled', true);
                $("#vehicle").prop('disabled', true);
            }else if( val == "PERSONAL"){
                $("#choice").prop('disabled', false);
                $("#vehicle").prop('disabled', true);
            }
        });

        $("#choice").change(function () {
            var val = $(this).val();
            var cat = $("#cat").val();

            if (val == "MOTOR" && cat == "PERSONAL") {
                $("#vehicle").prop('disabled', true);
            }else if (val == "CAR" && cat == "PERSONAL"){
                $("#vehicle").prop('disabled', true);
            }

            if (val == "MOTOR" && cat == "COMPANY") {
                $("#vehicle").prop('disabled', true);
            }else if (val == "CAR" && cat == "COMPANY"){
                $("#vehicle").prop('disabled', false);
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bfmcv3\agents\resources\views/admin/cases/create.blade.php ENDPATH**/ ?>