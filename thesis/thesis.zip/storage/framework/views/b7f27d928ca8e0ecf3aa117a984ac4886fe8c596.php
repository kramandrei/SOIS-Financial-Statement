
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Hospital Module</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.index')); ?>"><i class="bx bx-home-alt"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">Hospitals</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="row">
        <div class="col-12">
            <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#addNew"><i class="fa fa-plus-circle"></i> Create Entry</button>
        </div>
    </div> 
    <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
    <div class="card mt-2">
        <div class="card-body">
            <div class="border p-4 rounded">
                <table class="table table-striped data-table" style="text-transform: uppercase; font-size:11px;">
                    <thead>
                        <tr>
                            <th class="text-center">Region</th>
                            <th class="text-center">Branch</th>
                            <th class="text-center">Name</th>
                            <th class="text-center">Code</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</main>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('modals'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit<?php echo e($d->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'PATCH','action'=>['HospitalController@update',$d->id]]); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Update Hospital: <?php echo e($d->name); ?></h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="region_id" class="col-sm-3 col-form-label">Select Region</label>
                                <div class="col-sm-9">
                                    <select name="region" id="region_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id); ?>" <?php echo e(($d->region == $r->id) ? 'selected' : ''); ?>><?php echo e($r->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="branch_id" class="col-sm-3 col-form-label">Select Branch</label>
                                <div class="col-sm-9">
                                    <select name="branch_id" id="branch_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($b->id); ?>" <?php echo e(($d->branch_id == $b->id) ? 'selected' : ''); ?>><?php echo e($b->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="name" class="col-sm-3 col-form-label">Name</label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" class="form-control" id="name" value="<?php echo e($d->name); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="code" class="col-sm-3 col-form-label">Code</label>
                                <div class="col-sm-9">
                                    <input type="text" name="code" class="form-control" id="code" value="<?php echo e($d->code); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="office" class="col-sm-3 col-form-label">Office</label>
                                <div class="col-sm-9">
                                    <input type="text" name="office" class="form-control" id="office" value="<?php echo e($d->office); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="address" class="col-sm-3 col-form-label">Address</label>
                                <div class="col-sm-9">
                                    <input type="text" name="address" class="form-control" id="address" value="<?php echo e($d->address); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="km" class="col-sm-3 col-form-label">Distance Per Km</label>
                                <div class="col-sm-9">
                                    <input type="text" name="km" class="form-control" id="km" value="<?php echo e($d->km); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="rate" class="col-sm-3 col-form-label">Rate</label>
                                <div class="col-sm-9">
                                    <input type="text" name="rate" class="form-control" id="rate" value="<?php echo e($d->rate); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="addNew" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <?php echo Form::open(['method'=>'POST','action'=>'HospitalController@store']); ?>

        <div class="modal-content">
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div class="border p-4 rounded">
                            <div class="card-title d-flex align-items-center">
                                <h5 class="mb-0">Create Hospital</h5>
                            </div>
                            <hr>
                            <div class="row mb-3">
                                <label for="region_id" class="col-sm-3 col-form-label">Select Region</label>
                                <div class="col-sm-9">
                                    <select name="region" id="region_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($r->id); ?>"><?php echo e($r->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="branch_id" class="col-sm-3 col-form-label">Select Branch</label>
                                <div class="col-sm-9">
                                    <select name="branch_id" id="branch_id" class="form-control select2-sm">
                                        <option value=""> -- Select One --</option>
                                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($b->id); ?>"><?php echo e($b->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>       
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="name" class="col-sm-3 col-form-label">Name</label>
                                <div class="col-sm-9">
                                    <input type="text" name="name" class="form-control" id="name">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="code" class="col-sm-3 col-form-label">Code</label>
                                <div class="col-sm-9">
                                    <input type="text" name="code" class="form-control" id="code">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="office" class="col-sm-3 col-form-label">Office</label>
                                <div class="col-sm-9">
                                    <input type="text" name="office" class="form-control" id="office">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="address" class="col-sm-3 col-form-label">Address</label>
                                <div class="col-sm-9">
                                    <input type="text" name="address" class="form-control" id="address">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="km" class="col-sm-3 col-form-label">Distance Per Km</label>
                                <div class="col-sm-9">
                                    <input type="text" name="km" class="form-control" id="km" value="0.00">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="rate" class="col-sm-3 col-form-label">Rate</label>
                                <div class="col-sm-9">
                                    <input type="text" name="rate" class="form-control" id="rate" value="0.00">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
  $(function () {
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('hospitals.index')); ?>",
        columns: [
            {data: 'region', name: 'region'},
            {data: 'branch_id', name: 'branch_id'},
            {data: 'name', name: 'name'},
            {data: 'code', name: 'code'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bfmcv3\resources\views/admin/hospitals/index.blade.php ENDPATH**/ ?>