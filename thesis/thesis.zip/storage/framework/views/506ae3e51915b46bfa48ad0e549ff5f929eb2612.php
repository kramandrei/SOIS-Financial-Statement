
<?php $__env->startSection('content'); ?>
<main class="page-content">
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
      <div class="breadcrumb-title pe-3">Dashboard</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item active" aria-current="page">Monitoring Board</li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="mb-3"></div>
    <!--end breadcrumb-->
    <div class="row mb-3">
        <div class="col-12">
            <h6 class="mb-0 text-uppercase">Agent Tasks</h6>
            <hr/>
            <table class="table table-striped data-table" style="text-transform: uppercase;">
                <thead>
                    <tr>
                        <th class="text-center">Date</th>
                        <th class="text-center">Agent Assigned</th>
                        <th class="text-center">Customer</th>
                        <th class="text-center">Task</th>
                        <th class="text-center" width="50">Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-12">
            <h6 class="mb-0 text-uppercase">Case Setups</h6>
            <hr/>
            <div class="card" style="font-size: 11px;">
                <div class="card-body">
                    <div style="text-transform: uppercase;">
                        <ul class="nav nav-pills mb-3" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" data-bs-toggle="pill" href="#open" role="tab" aria-selected="true">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-title">Open [<?php echo e($cases->where('caseStatus', 1)->count()); ?>]</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="pill" href="#delivered" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-title">Delivered [<?php echo e($cases->where('caseStatus', 2)->count()); ?>]</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="pill" href="#pullout" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-title">Pull Out [<?php echo e($cases->where('caseStatus', 3)->count()); ?>]</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="pill" href="#receivable" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-title">Receivable [<?php echo e($cases->where('caseStatus', 4)->count()); ?>]</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="pill" href="#paid" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-title">Paid [<?php echo e($cases->where('caseStatus', 5)->count()); ?>]</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="pill" href="#collected" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-title">Collected [<?php echo e($cases->where('caseStatus', 6)->count()); ?>]</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="pill" href="#cancelled" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-title">Cancelled [<?php echo e($cases->where('caseStatus', 7)->count()); ?>]</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="pill" href="#balance" role="tab" aria-selected="false">
                                    <div class="d-flex align-items-center">
                                        <div class="tab-title">With Balance [<?php echo e($cases->where('caseStatus', 8)->count()); ?>]</div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="open" role="tabpanel">
                            <table class="table table-striped table1" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Delivery Date</th>
                                        <th class="text-center">Surgery Date</th>
                                        <th class="text-center">Branch</th>
                                        <th class="text-center">Agent</th>
                                        <th class="text-center">Case</th>
                                        <th class="text-center">Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cases->where('caseStatus',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_delivery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_surgery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e($data->branch->code); ?></td>
                                        <td><?php echo e($data->agent->code); ?></td>
                                        <td><?php echo e($data->implantcase->name); ?></td>
                                        <td><?php echo e(($data->hospital == NULL) ? '-' : $data->hospital->code); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="delivered" role="tabpanel">
                            <table class="table table-striped table1" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Delivery Date</th>
                                        <th class="text-center">Surgery Date</th>
                                        <th class="text-center">Branch</th>
                                        <th class="text-center">Agent</th>
                                        <th class="text-center">Case</th>
                                        <th class="text-center">Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cases->where('caseStatus',2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_delivery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_surgery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e($data->branch->code); ?></td>
                                        <td><?php echo e($data->agent->code); ?></td>
                                        <td><?php echo e($data->implantcase->name); ?></td>
                                        <td><?php echo e(($data->hospital == NULL) ? '-' : $data->hospital->code); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="pullout" role="tabpanel">
                            <table class="table table-striped table1" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Delivery Date</th>
                                        <th class="text-center">Pullout Date</th>
                                        <th class="text-center">Branch</th>
                                        <th class="text-center">Agent</th>
                                        <th class="text-center">Case</th>
                                        <th class="text-center">Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cases->where('caseStatus',3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_delivery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e(($data->case_close != NULL) ? \Carbon\Carbon::parse($data->case_close->date)->toFormattedDateString() : ''); ?></td>
                                        <td><?php echo e($data->branch->code); ?></td>
                                        <td><?php echo e($data->agent->code); ?></td>
                                        <td><?php echo e($data->implantcase->name); ?></td>
                                        <td><?php echo e(($data->hospital == NULL) ? '-' : $data->hospital->code); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="receivable" role="tabpanel">
                            <table class="table table-striped table1" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Delivery Date</th>
                                        <th class="text-center">Pullout Date</th>
                                        <th class="text-center">Branch</th>
                                        <th class="text-center">Agent</th>
                                        <th class="text-center">Case</th>
                                        <th class="text-center">Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cases->where('caseStatus',4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_delivery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e(($data->case_close != NULL) ? \Carbon\Carbon::parse($data->case_close->date)->toFormattedDateString() : ''); ?></td>
                                        <td><?php echo e($data->branch->code); ?></td>
                                        <td><?php echo e($data->agent->code); ?></td>
                                        <td><?php echo e($data->implantcase->name); ?></td>
                                        <td><?php echo e(($data->hospital == NULL) ? '-' : $data->hospital->code); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="paid" role="tabpanel">
                            <table class="table table-striped table1" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Delivery Date</th>
                                        <th class="text-center">Pullout Date</th>
                                        <th class="text-center">Branch</th>
                                        <th class="text-center">Agent</th>
                                        <th class="text-center">Case</th>
                                        <th class="text-center">Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cases->where('caseStatus',5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_delivery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e(($data->case_close != NULL) ? \Carbon\Carbon::parse($data->case_close->date)->toFormattedDateString() : ''); ?></td>
                                        <td><?php echo e($data->branch->code); ?></td>
                                        <td><?php echo e($data->agent->code); ?></td>
                                        <td><?php echo e($data->implantcase->name); ?></td>
                                        <td><?php echo e(($data->hospital == NULL) ? '-' : $data->hospital->code); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="collected" role="tabpanel">
                            <table class="table table-striped table1" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Delivery Date</th>
                                        <th class="text-center">Pullout Date</th>
                                        <th class="text-center">Branch</th>
                                        <th class="text-center">Agent</th>
                                        <th class="text-center">Case</th>
                                        <th class="text-center">Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cases->where('caseStatus',6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_delivery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e(($data->case_close != NULL) ? \Carbon\Carbon::parse($data->case_close->date)->toFormattedDateString() : ''); ?></td>
                                        <td><?php echo e($data->branch->code); ?></td>
                                        <td><?php echo e($data->agent->code); ?></td>
                                        <td><?php echo e($data->implantcase->name); ?></td>
                                        <td><?php echo e(($data->hospital == NULL) ? '-' : $data->hospital->code); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="cancelled" role="tabpanel">
                            <table class="table table-striped table1" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Delivery Date</th>
                                        <th class="text-center">Pullout Date</th>
                                        <th class="text-center">Branch</th>
                                        <th class="text-center">Agent</th>
                                        <th class="text-center">Case</th>
                                        <th class="text-center">Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cases->where('caseStatus',7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_delivery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e(($data->case_close != NULL) ? \Carbon\Carbon::parse($data->case_close->date)->toFormattedDateString() : ''); ?></td>
                                        <td><?php echo e($data->branch->code); ?></td>
                                        <td><?php echo e($data->agent->code); ?></td>
                                        <td><?php echo e($data->implantcase->name); ?></td>
                                        <td><?php echo e(($data->hospital == NULL) ? '-' : $data->hospital->code); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="balance" role="tabpanel">
                            <table class="table table-striped table1" style="text-transform: uppercase;">
                                <thead>
                                    <tr>
                                        <th class="text-center">Delivery Date</th>
                                        <th class="text-center">Pullout Date</th>
                                        <th class="text-center">Branch</th>
                                        <th class="text-center">Agent</th>
                                        <th class="text-center">Case</th>
                                        <th class="text-center">Hospital</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $cases->where('caseStatus',8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Carbon\Carbon::parse($data->date_delivery)->toFormattedDateString()); ?></td>
                                        <td><?php echo e(($data->case_close != NULL) ? \Carbon\Carbon::parse($data->case_close->date)->toFormattedDateString() : ''); ?></td>
                                        <td><?php echo e($data->branch->code); ?></td>
                                        <td><?php echo e($data->agent->code); ?></td>
                                        <td><?php echo e($data->implantcase->name); ?></td>
                                        <td><?php echo e(($data->hospital == NULL) ? '-' : $data->hospital->code); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
  $(function () {
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('dashboard.index')); ?>",
        columns: [
            {data: 'date', name: 'date'},
            {data: 'agent_id', name: 'agent_id'},
            {data: 'customer_id', name: 'customer_id'},
            {data: 'task_what', name: 'task_what'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\bfmcv3\agents\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>