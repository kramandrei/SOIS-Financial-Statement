<!--start top header-->
<header class="top-header">        
    <nav class="navbar navbar-expand gap-3">
        <div class="mobile-toggle-icon fs-3">
            <i class="bi bi-list"></i>
        </div>
        <div class="chip chip-md bg-dark text-white mt-2">
            BFMC - <span style="color:yellow; text-transform: uppercase;">SALES APP</span>
        </div>
        <div class="chip chip-md bg-dark text-white mt-2">
            Currently Logged In: <span style="color:yellow; text-transform: uppercase;"><?php echo e(Auth::user()->name); ?> | <?php echo e(Auth::user()->usertype->name); ?></span>
        </div>
    </nav>
</header>
<!--end top header--><?php /**PATH C:\xampp\htdocs\bfmcv3\agents\resources\views/layouts/partials/nav.blade.php ENDPATH**/ ?>