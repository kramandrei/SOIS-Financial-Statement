<?php if($errors->any()): ?>
    <div class="alert alert-danger border-0 bg-danger alert-dismissible fade show">
        <div class="text-white">Check out the errors</div>
        <ul style="margin-top:10px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><span style="font-weight: bold;margin-top:10px;text-transform:uppercase;color:white;"><?php echo e($error); ?></span></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?><?php /**PATH D:\laragon\www\bfmcv3\agents\resources\views/alert.blade.php ENDPATH**/ ?>